import React from "react";

const UpdateGardener = () => {
  return <div>update gardger</div>;
};

export default UpdateGardener;
